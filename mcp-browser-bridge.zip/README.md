# Windsurf-MCP-Bridge

稳定的 MCP 浏览器中台服务，为 Windsurf 提供持久化、可复用的浏览器操作能力。

## 特性

- 🔗 **Streamable HTTP** - 基于 MCP 现代标准，比 SSE 更稳定
- 🍪 **状态持久化** - 保持登录状态，跨窗口共享
- 📸 **截图能力** - AI 可"看见"网页
- 🔍 **日志透传** - 实时获取 console 输出
- 🛡️ **进程守护** - PM2 自动重启

## 快速开始

### 方式一：一键安装（推荐）

**Windows 用户** - 双击 `install.bat`

自动完成：Node.js检查 → PM2安装 → 依赖安装 → Playwright安装 → 项目构建

### 方式二：手动安装

```bash
npm install
npx playwright install chromium
npm run build
```

### 2. 一键启动

**Windows 用户** - 双击 `start.bat`

**命令行启动**
```bash
npm start
```

启动后会自动输出 MCP 配置，直接复制即可：

```
╔══════════════════════════════════════════════════════════════╗
║           Windsurf MCP Bridge - 一键启动                      ║
╚══════════════════════════════════════════════════════════════╝

📋 复制以下配置到 Windsurf MCP 设置中:

{
  "mcpServers": {
    "stable-browser": {
      "serverUrl": "http://localhost:3211/mcp"
    }
  }
}
```

### 3. 后台运行 (PM2)

```bash
npm run pm2:start
```

## 可用工具

| 工具 | 描述 |
|------|------|
| `navigate` | 跳转至指定网址 |
| `click` | 点击页面元素 |
| `type` | 输入文本 |
| `take_screenshot` | 截取页面截图 |
| `get_console_logs` | 获取控制台日志 |
| `get_network` | 获取网络请求 |
| `execute_js` | 执行 JavaScript |

## 目录结构

```
windsurf-mcp-bridge/
├── src/
│   ├── browser.ts    # Playwright 浏览器管理
│   ├── server.ts     # Express + Streamable HTTP 服务
│   ├── tools.ts      # MCP 工具定义
│   ├── types.ts      # TypeScript 类型
│   └── schemas.ts    # Zod 验证
├── storage/
│   ├── user_data/    # 浏览器缓存
│   └── screenshots/  # 截图文件
└── ecosystem.config.cjs  # PM2 配置
```

## 环境变量

复制 `.env.example` 为 `.env` 并按需修改：

| 变量 | 默认值 | 描述 |
|------|--------|------|
| `PORT` | 3211 | 服务端口 |
| `HEADLESS` | false | 无头模式 |
| `USER_DATA_DIR` | storage/user_data | 用户数据目录 |
| `DEVTOOLS` | true | 自动打开 Chrome DevTools |
| `SLOW_MO` | 0 | 操作延迟(ms)，0=最快 |

## 性能优化

服务已内置大量性能优化参数：

- **禁用不必要的 Chrome 功能**: 扩展、同步、后台网络等
- **内存优化**: 限制 V8 堆大小
- **DevTools 支持**: 可通过 `DEVTOOLS=true` 启用远程调试端口 9222
- **零延迟模式**: `SLOW_MO=0` 确保最快操作速度

## PM2 命令

```bash
npm run pm2:start    # 启动
npm run pm2:stop     # 停止
npm run pm2:restart  # 重启
npm run pm2:logs     # 查看日志
```
